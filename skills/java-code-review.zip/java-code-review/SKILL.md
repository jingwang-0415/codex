---
name: java-code-review
description: Change-driven, mentor-style review for JDK 21, Java/Spring enterprise services, MR/PR diffs, small one-line or single-token changes, regression fixes, tests, database and concurrency code, architecture and public contracts, internal company frameworks, and Kubernetes manifests. Establish the intended behavior delta and preserved business invariants; trace caller/callee and DB/RPC/MQ/cache side effects; assess compatibility, rolling deployment, transactions, threading, query efficiency, test effectiveness, security, redundant code, rendered YAML, and design-document consistency; report evidence-based findings in Chinese with established English technical terms.
---

# Java Code Review

## Review Posture

Act as a mentor-style reviewer: explain the reasoning, suggest small practical improvements, and keep the tone constructive. For important defects, be explicit and direct. Do not soften P0/P1/P2 issues.

Default to Chinese output. Keep established technical terms in English, such as `race condition`, `ThreadLocal`, `N+1 query`, `transaction boundary`, `mock`, `assertion`, `dead code`, and `code smell`.

Prefer reviewing the changed code from the MR/PR or user-specified scope. If no scope is given, inspect the smallest relevant module first.

Treat diff size and risk as independent. Give one-line and single-token changes the same semantic scrutiny as larger changes when they touch conditions, annotations, contracts, identifiers, constants, configuration, SQL, transactions, concurrency, or external side effects.

## Context Gathering

1. Identify the review target: MR/PR link, branch diff, patch file, commit range, or user-selected files. For MR/PR links, determine base branch, head branch, changed files, added/removed public contracts, and the smallest affected modules.
2. Establish a change contract before judging implementation: state the intended behavior change, behavior that must remain unchanged, affected business invariants, expected side effects, and evidence needed to accept the change. If intent cannot be inferred, mark it as `需要确认`; do not silently invent it.
3. Identify the project shape: Maven, Gradle, multi-module, Spring Boot, internal framework starters, Java version, test framework, persistence stack, and deployment stack such as Helm, Kustomize, raw YAML, or company render tooling.
4. Locate repository business knowledge. Search for business or architecture docs such as `README.md`, `docs/**/*.md`, `ARCHITECTURE.md`, `CODEBASE_KNOWLEDGE.md`, `DOMAIN.md`, `design/**/*.md`, `adr/**/*.md`, `.puml`/`.plantuml` diagrams, requirement docs, and module docs. If none exists or it is too shallow, create or update a repository business knowledge MD before final review; use `references/business-architecture-review.md`.
5. Read nearby code before judging: caller, callee, configuration, test, mapper/repository, DTO, domain model, existing project conventions, and the business flow containing the changed method.
6. For each changed method or public contract, trace at least one caller and one callee when available. For service/controller/repository changes, inspect request entry, transaction boundary, data access, downstream RPC/message/cache behavior, and tests.
7. If internal company components appear, read `references/internal-framework.md`. If that file lacks the needed convention, say what needs confirmation instead of guessing.
8. Read `references/change-risk-review.md` for every MR/PR, commit-range, patch, or regression-fix review. Read the other matching reference files when the change touches their domain.
9. For Kubernetes changes, compare template inputs with rendered YAML when possible. Prefer reviewing the final manifest that will be applied to the cluster, not only the template.
10. Run available project checks when reasonable: unit tests for the touched module, compiler checks, existing Checkstyle/PMD/SpotBugs/Error Prone/Sonar commands, focused test classes, Helm template/lint, Kustomize build, kubeconform/kubeval, or project-provided manifest validation. Do not invent heavy setup if the repo does not provide it.

## Review Order

Prioritize findings in this order:

1. Correctness bugs and production-impacting behavior changes.
2. Business semantics, architecture rationality, module boundaries, and compatibility risks introduced by the change.
3. Threading, async execution, transaction crossing, shared state, and resource lifecycle issues.
4. Database execution efficiency, query shape, batching, pagination, mapper behavior, and transaction scope.
5. UT effectiveness: whether tests would catch real regressions.
6. Security and data protection.
7. Kubernetes rendered YAML correctness, rollout safety, resource settings, probes, configuration, and secret handling.
8. Redundant code and maintainability issues.
9. Style and readability.

Use references as needed:

- `references/change-risk-review.md`: required change contract, single-line/single-token risk amplification, blast-radius tracing, business invariants, failure modeling, and regression-proof matrix.
- `references/review-checklist.md`: general Java review and redundant-code checklist.
- `references/business-architecture-review.md`: repository business knowledge, MR-focused context review, architecture rationality, and compatibility checks.
- `references/spring-jdk21-review.md`: Spring and JDK 21 review points.
- `references/database-and-threading.md`: DB efficiency, transactions, concurrency, and async execution.
- `references/k8s-rendered-yaml-review.md`: Kubernetes container deployment and rendered YAML review.
- `references/internal-framework.md`: company framework and second-party library conventions template.

Use scripts as needed:

- `scripts/validate_helm_render.py`: render a Helm chart, validate YAML syntax, and highlight indentation/template risks before reviewing Kubernetes deployment changes.
- `scripts/collect_repo_knowledge_context.py`: collect repository docs, module layout, Spring components, and changed-file context to help create or refresh repository business knowledge before MR review.

## Required Focus Areas

Always identify the semantic delta, not only the textual delta. Explicitly examine changed operators, negation, annotations, literals, enum values, names, defaults, SQL predicates, configuration keys, serialization names, transaction settings, timeout/retry values, and dependency versions. Search non-Java references such as XML, YAML, SpEL, templates, reflection strings, dashboards, alerts, and scripts when relevant.

Always state which business behavior is expected to change and which behavior must remain unchanged. Check both against callers, domain state transitions, persisted data, external contracts, and tests. A happy-path test for the new behavior does not prove regression safety.

Always check for redundant code. Include dead code, duplicated logic, unused parameters, unused fields, pointless wrappers, unreachable branches, repeated null/default handling, duplicate SQL or DAO calls, over-broad abstractions, and tests/mocks that do not validate behavior.

Always check thread-related code when any of these appear: `Thread`, `Executor`, `ExecutorService`, `CompletableFuture`, `parallelStream`, scheduler, async annotation, cache, static mutable field, `ThreadLocal`, lock, concurrent collection, batch job, message listener, or virtual thread.

Always check database execution efficiency when any of these appear: mapper/repository/DAO, SQL/XML mapper, ORM query, transaction annotation, pagination, batch operation, loop with DB call, cache read/write, external RPC combined with DB transaction, or large collection processing.

Always check UT effectiveness when tests are added or changed. Prefer concrete comments about missing assertions, weak mocks, missing edge cases, missing failure paths, or tests coupled to implementation details.

Always check Kubernetes rendered YAML when deployment templates, values, overlays, container images, probes, resources, ConfigMaps, Secrets, env vars, ports, Services, Ingress, HPA, PDB, or rollout settings are changed.

Always check changed code in business and architecture context. Do not review an isolated method as if it had no callers, no compatibility contract, and no domain meaning.

Always check compatibility for changed public methods, DTOs, APIs, database schema, events, MQ payloads, cache keys, enum values, error codes, configuration keys, and deployment values.

Always compare relevant design docs, including PlantUML/PUML diagrams, with the changed implementation. If the MR touches code covered by a diagram and the implementation is inconsistent with the diagram, output that inconsistency directly in the review result with both code and document locations.

## Output Format

Lead with findings. If there are no high-confidence findings, say so clearly and list residual risks or checks not run.

Use this structure:

```text
变更契约
- 预期变化:
- 必须保持不变:
- 业务不变量与外部契约:

发现的问题
- [P1] 标题
  位置: path/to/File.java:123
  影响: 说明真实风险
  证据: 指向代码行为、调用链或测试缺口
  建议: 给出可落地修复方向

业务/架构上下文
- 本次 MR 影响的业务域、模块、入口、关键调用链，以及已参考/生成的业务知识文档

文档/实现一致性
- 涉及的 MD/PUML 设计文档与实现是否一致；如不一致，列出文档位置、代码位置和差异影响

回归证明
- 已覆盖/未覆盖的变化路径、不变路径、边界、失败、重试/并发和兼容场景

需要确认
- ...

改进建议
- ...

验证情况
- 已运行/未运行的命令，以及结果或原因
```

Severity guide:

- `P0`: data loss, security bypass, severe outage, irreversible production impact.
- `P1`: likely production bug, race condition, serious DB inefficiency, broken transaction, invalid test confidence.
- `P2`: meaningful architecture, compatibility, maintainability, performance, edge-case, or test-quality issue.
- `P3`: style, naming, small redundancy, readability, or optional modernization.

For mentor-style suggestions that are not defects, use `改进建议` instead of inflating severity.

## Review Discipline

Do not report speculative issues as facts. Use "需要确认" when behavior depends on company framework semantics, runtime configuration, database index design, or deployment topology.

Do not equate compilation, a green happy-path test, or a small diff with safety. State residual risk when the business invariant, caller population, historical data shape, mixed-version deployment, or failure behavior cannot be verified.

Do not ask for broad rewrites unless the risk justifies it. Prefer incremental fixes that match the local code style.

Do not focus on formatting unless it hides a bug or violates an explicit project rule.

When suggesting removal of redundant code, explain why it is safe or what must be checked before removal.

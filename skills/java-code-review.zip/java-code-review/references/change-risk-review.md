# Change-Risk Review

Use this reference for every MR/PR, commit-range, patch, regression fix, and small one-line or single-token change.

## Change Contract

Establish the contract before reviewing implementation:

- `预期变化`: Describe the observable behavior that should change.
- `必须保持不变`: Describe nearby behavior, callers, data, and contracts that must not change.
- `业务不变量`: Identify state, money, inventory, permission, tenancy, ordering, uniqueness, idempotency, and audit rules that must always hold.
- `允许的副作用`: List expected DB writes, cache changes, MQ events, RPC calls, files, logs, metrics, and notifications.
- `验收证据`: Identify the tests, queries, rendered config, contract comparison, or runtime evidence needed for acceptance.

Infer these from requirements, issue/MR description, business docs, PlantUML, code, tests, schemas, and established behavior. Mark unsupported assumptions as `需要确认`.

## Semantic Delta

Translate textual edits into runtime effects. Inspect removed code as carefully as added code.

Treat these small edits as risk amplifiers:

- `>`, `>=`, `<`, `<=`, `==`, `!=`, `&&`, `||`, negation, parentheses, and branch order.
- Transaction, async, retry, cache, validation, authorization, serialization, scheduling, and dependency-injection annotations.
- Numeric, monetary, time, timeout, retry, batch-size, page-size, TTL, and threshold literals.
- Enum values, defaults, status transitions, error codes, feature flags, and fallback behavior.
- Method, field, bean, DTO, JSON, table, column, topic, cache-key, metric, and configuration names.
- SQL predicates, joins, ordering, grouping, limits, locking, and null handling.
- Dependency/plugin/image versions and deployment values.

For renames, search Java and non-Java references: XML, MyBatis mappings, YAML, JSON fixtures, SpEL, reflection strings, templates, SQL, shell scripts, dashboards, alerts, documentation, and external contracts. Compilation alone is insufficient.

## Blast Radius

For every changed symbol or contract:

1. Trace representative callers and classify their input assumptions.
2. Trace risky callees: DB, RPC, MQ, cache, lock, executor, scheduler, file, and deployment config.
3. Identify transaction, thread, tenant, security, tracing, and request-context boundaries.
4. Identify persisted or in-flight artifacts: rows, cache entries, events, jobs, files, and historical payloads.
5. Check old/new mixed-version behavior during rolling deployment.
6. Search design documents and PlantUML for the affected domain terms and flow.

Review only relevant context, but do not declare an isolated method safe without this trace.

## Business Evidence

Prefer evidence in this order:

1. Explicit requirement, accepted business rule, API/schema contract, or current authoritative design decision.
2. Executable behavior: integration/contract tests, schema constraints, production-compatible configuration, and established public interfaces.
3. Consistent implementation across caller, service, persistence, event, and deployment layers.
4. Unit tests and code comments.
5. Naming or industry convention.

Do not override repository-specific behavior with generic industry practice. Use industry practice to identify questions and risks, not to invent business truth.

## Failure Model

Check the change under:

- Empty, null, minimum, maximum, threshold, duplicate, stale, and out-of-order input.
- Timeout, partial success, downstream error, retry, cancellation, and process restart.
- Concurrent requests, duplicate messages, scheduled overlap, and multiple service instances.
- Transaction rollback, event publication timing, cache failure, and compensation failure.
- Old data, old messages, absent configuration, and old/new version coexistence.

Determine whether retries repeat a side effect and whether idempotency is enforced at the correct boundary.

## Regression-Proof Matrix

Require evidence proportional to risk:

| Evidence | Purpose |
|---|---|
| Intended-change test | Prove the requested behavior now differs |
| Preserved-behavior test | Prove adjacent old behavior remains unchanged |
| Boundary test | Prove operators, thresholds, dates, amounts, and empty/null behavior |
| Failure-path test | Prove rollback, error mapping, retry, and compensation behavior |
| Duplicate/concurrency test | Prove idempotency and shared-state safety when applicable |
| Compatibility test | Prove old payload/data/config or mixed-version behavior |
| Integration/render validation | Prove SQL, serialization, framework, or deployment semantics |

Do not accept a test merely because it executes the changed line. Check assertions against observable business outcomes. Identify weak mocks that encode the implementation instead of validating the contract.

## Review Decision

Report a finding only when evidence connects changed code to an impact. Include location, impact, evidence, and a bounded remediation.

Use `需要确认` when intent, framework semantics, data shape, index design, deployment topology, or business ownership is unknown. State why the uncertainty matters and the exact artifact or owner needed to resolve it.

If no high-confidence defect is found, state residual risks and checks not run. Never use small diff size, compilation, or green happy-path tests as the sole safety argument.

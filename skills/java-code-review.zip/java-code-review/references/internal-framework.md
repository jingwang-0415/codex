# Internal Framework Notes

This file is a living template for company-specific Spring-based framework and second-party library conventions. Update it as conventions become known.

## Review Rule

When code uses an internal component not documented here, do not infer its semantics with high confidence. Put the item under "需要确认" and ask for the specific behavior needed to complete the review.

## Areas to Fill

### Base Framework

- Application starter conventions:
- Common annotations and AOP behavior:
- Request context and tenant/user context propagation:
- Global exception handling:
- Unified response model:
- Logging and tracing conventions:

### Data Access

- DAO/Mapper framework:
- Pagination helper:
- Batch API:
- Transaction conventions:
- Optimistic/pessimistic locking helpers:
- Read/write splitting or multi-data-source behavior:

### RPC and External Calls

- RPC client conventions:
- Timeout and retry defaults:
- Circuit breaker/fallback behavior:
- Error mapping:
- Context propagation:

### Cache

- Cache library:
- Key format:
- TTL defaults:
- Invalidation conventions:
- Stampede/penetration protection:

### Messaging and Jobs

- Message framework:
- Consumer concurrency:
- Retry and dead-letter behavior:
- Idempotency convention:
- Scheduled job locking:

### Testing

- Standard test stack:
- Internal test base classes:
- DB test approach:
- Mocking guidance:
- Required UT naming or assertion conventions:

### Kubernetes and Deployment Platform

- Render tool: Helm.
- Standard render command:
- Required validation command:
- Platform default resources:
- Required labels/annotations:
- Required probes:
- Actuator/management port convention:
- Graceful shutdown convention:
- Service mesh or ingress convention:
- HPA/VPA convention:
- PDB/topology spread convention:
- Secret management system:
- Config rollout/reload convention:
- Image tag and registry convention:
- Production namespace/environment overlay convention:

## Known Internal Components

Add entries in this format:

```text
Component:
Purpose:
Important semantics:
Review risks:
Preferred test approach:
```

# Spring and JDK 21 Review

## Spring Service Review

- Check `@Transactional` boundaries: self-invocation, private methods, checked exceptions, async calls, external RPC inside transactions, and transaction scope that covers slow IO.
- Check controller validation: `@Valid`, binding errors, enum parsing, default values, and consistent error responses.
- Check controller-level `@ModelAttribute` methods: they can run before handler methods and may cause duplicate repository calls, unexpected model population, or exceptions on routes that do not need the loaded entity.
- Check bean lifecycle and injection: circular dependencies, static access to beans, mutable singleton state, and conditional beans.
- Check cache use: key correctness, invalidation path, stale reads, cache penetration, cache stampede, and tenant/user isolation.
- Check scheduled jobs and message listeners for idempotency, retry behavior, poison message handling, and duplicate execution.

## JDK 21

- Use modern Java features when they clarify intent, not for novelty.
- `record` is good for immutable data carriers, but check serialization, framework binding, validation, and binary compatibility.
- `sealed` types are useful for closed domain hierarchies, but avoid them when extension by internal framework or downstream modules is expected.
- Pattern matching can simplify type checks, but avoid dense conditions that obscure business rules.
- `var` is acceptable when the right side makes the type obvious. Avoid it for factory methods, generics, numeric types, or domain-sensitive values.
- Virtual threads can improve blocking IO scalability, but review `ThreadLocal`, pinning risk, synchronized blocks, connection pool limits, and observability assumptions.

## Framework Compatibility

- Confirm whether company base classes, annotations, interceptors, filters, or starters impose behavior beyond standard Spring.
- Do not recommend removing framework hooks, annotations, or wrappers unless their role is understood.
- If an internal component's behavior is unclear, move the item to "需要确认" and name the exact semantic needed.

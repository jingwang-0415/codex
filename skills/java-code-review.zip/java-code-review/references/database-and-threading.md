# Database and Threading Review

## Database Efficiency

- Look for `N+1 query`, loop-level select/update/insert/delete, repeated lookup by the same key, and missing batch APIs.
- Check pagination is pushed down to the database and has deterministic ordering.
- Check large result sets are streamed, paged, or bounded instead of loaded fully into memory.
- Check dynamic SQL for missing conditions, accidental full table scans, unsafe string interpolation, and empty `IN` behavior.
- Check index friendliness: leading wildcard `LIKE`, functions on indexed columns, implicit type conversion, non-sargable predicates, and mismatched sort order.
- Check transaction size: avoid holding transactions during remote calls, long CPU work, file IO, message send, or slow batch loops.
- Check read/write consistency, idempotency, duplicate submit handling, optimistic locking, and lost update risk.

## ORM and Mapper

- For MyBatis/XML/dynamic SQL, inspect generated query shape when possible.
- For JPA/Hibernate, check lazy loading outside transaction, unintended eager loading, dirty checking side effects, cascade scope, and batch settings.
- For internal DAO frameworks, consult `internal-framework.md` before assuming semantics.

## Threading and Async

- Check shared mutable state in singleton Spring beans.
- Check thread pool sizing, queue capacity, rejection policy, naming, lifecycle shutdown, and isolation between latency-sensitive and batch workloads.
- Check `CompletableFuture` uses an explicit executor when default common-pool behavior is inappropriate.
- Check async exception handling. Exceptions must be observed, logged with context, and mapped to retry/failure behavior.
- Check `ThreadLocal` cleanup and context propagation. Be careful with virtual threads and pooled threads.
- Check locks for scope, ordering, timeout, and interaction with DB transactions or remote calls.
- Avoid `parallelStream` for request-path logic unless workload, executor behavior, and thread safety are understood.
- Check scheduled jobs, batch tasks, and message consumers for idempotency and concurrency limits.

## Reporting Thread/DB Findings

For each finding, include:

- Triggering code path.
- Production impact: latency, contention, stale data, duplicate writes, lost updates, deadlock, pool exhaustion, or inconsistent transaction behavior.
- A practical fix: bulk query, batch write, smaller transaction, explicit executor, bounded queue, idempotency key, lock narrowing, or test coverage.

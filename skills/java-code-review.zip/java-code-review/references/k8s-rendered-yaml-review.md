# Kubernetes Rendered YAML Review

Use this reference when reviewing Kubernetes manifests, Helm charts, Kustomize overlays, raw YAML, company deployment templates, CI/CD rendering scripts, or Java service container deployment changes.

For Helm-rendered YAML failures caused by whitespace, indentation, or template alignment, run `scripts/validate_helm_render.py` when possible before manual review.

## Review Scope

Prefer the final rendered YAML over only the source template. Many production issues appear only after values, profiles, overlays, or environment-specific substitutions are merged.

Collect, when available:

- Source template: Helm chart, Kustomize base/overlay, raw YAML, Jsonnet, company DSL, or CI render script.
- Input values: `values.yaml`, environment values, profile-specific patches, image tag, config files, and secret references.
- Render command: `helm template`, `helm lint`, `kustomize build`, `kubectl kustomize`, company render command, or CI job output.
- Final manifest that will be applied.
- Target environment assumptions: namespace, cluster version, ingress controller, service mesh, HPA/VPA, PodSecurity policy, and company platform defaults.

If the final rendered YAML is unavailable, state that confidence is limited and review template risks separately from render risks.

## Rendering and Template Risks

- Check required values cannot render as empty strings, `null`, wrong type, wrong unit, or invalid YAML indentation.
- Treat YAML parse failures from Helm render as P1 when they block pod creation or rollout. The first goal is to reproduce with the exact chart, values, namespace, release name, and `--set` parameters used by CI/CD.
- Check environment overlays do not accidentally remove probes, resources, labels, annotations, ports, volumes, or security settings.
- Check image repository/tag/pull policy are resolved correctly and do not default to `latest` for production.
- Check names, labels, selectors, and Service target labels stay consistent after templating. A selector mismatch is a P1 issue because traffic may not reach pods.
- Check duplicate keys in YAML and duplicate env var names. YAML parsers may silently keep the last value.
- Check `tpl`, string interpolation, or company render functions do not expose secrets in rendered manifests or logs.
- Check generated names remain within Kubernetes length limits and are stable across upgrades where stability matters.

## Helm Whitespace and Indentation Workflow

When the pain point is "YAML error after Helm render":

1. Reproduce the exact render command. Prefer the CI/CD command; otherwise use:

```bash
python3 /path/to/java-code-review/scripts/validate_helm_render.py ./chart --release RELEASE -f values.yaml --output /tmp/rendered.yaml
```

2. If `helm template` fails, read the Helm error first. Helm usually reports the template file and approximate line where YAML conversion failed.
3. If `helm template` succeeds but Kubernetes rejects YAML, parse the rendered file and inspect the manifest around the reported line.
4. Map the rendered line back to a template by searching nearby unique keys, labels, env names, or container names in `templates/`.
5. Fix the template, not the rendered YAML.

High-frequency Helm whitespace issues:

- Using `indent` where `nindent` is needed after a key, causing child YAML to stay on the same line or at the wrong depth.
- Rendering `toYaml` without `nindent` or with the wrong indentation level.
- Putting a conditional block under a YAML key without ensuring the key is omitted when the block is empty.
- Mixing list item indentation and conditionals, especially under `env`, `volumeMounts`, `volumes`, `ports`, `containers`, `initContainers`, `affinity`, and `tolerations`.
- Emitting an empty map/list where Kubernetes expects an object, or emitting nothing after `key:`.
- Using tabs in YAML indentation.
- Trimming whitespace with `{{-` or `-}}` in a way that joins two YAML tokens.
- Quoting values inconsistently so booleans, numbers, memory units, or colon-containing strings render unexpectedly.

Preferred template patterns:

```yaml
resources:
{{- toYaml .Values.resources | nindent 10 }}
```

```yaml
{{- with .Values.nodeSelector }}
nodeSelector:
{{- toYaml . | nindent 8 }}
{{- end }}
```

```yaml
env:
  - name: SPRING_PROFILES_ACTIVE
    value: {{ .Values.springProfile | quote }}
{{- with .Values.extraEnv }}
{{- toYaml . | nindent 2 }}
{{- end }}
```

Do not blindly copy these indentation numbers. Match the surrounding manifest depth.

## Deployment and Rollout Safety

- Check `replicas`, `strategy`, `maxSurge`, `maxUnavailable`, `progressDeadlineSeconds`, and `minReadySeconds` match availability needs.
- For single-replica services, call out that rolling update cannot provide true zero downtime unless platform routing and startup behavior make it acceptable.
- Check `readinessProbe` protects traffic routing, `livenessProbe` does not restart slow-but-recovering apps, and `startupProbe` exists for slow Spring Boot startup when needed.
- Check `terminationGracePeriodSeconds` and `preStop` allow graceful shutdown, request draining, and message/job cleanup.
- Check `PodDisruptionBudget` and anti-affinity/topology spread when availability matters.

## Resources, JVM, and Autoscaling

- Check CPU and memory `requests` and `limits` exist or are intentionally inherited from platform defaults.
- Check Java heap/container memory alignment: `-Xmx`, `MaxRAMPercentage`, metaspace, direct memory, thread stacks, and native memory must fit within memory limits.
- Watch for CPU limits that may throttle latency-sensitive Java services. If HPA uses CPU, ensure requests are meaningful.
- Check HPA target metric, min/max replicas, and scaling behavior align with service traffic and startup time.
- Check batch jobs and consumers use resource settings appropriate for throughput and backpressure.

## Configuration, Secrets, and Environment

- Check ConfigMaps contain non-confidential configuration only. Credentials, tokens, private keys, and passwords belong in Secrets or external secret systems.
- Check `envFrom` cannot accidentally inject conflicting names. Prefer explicit `env` for critical settings.
- Check config changes trigger rollout when mounted ConfigMaps/Secrets are expected to refresh only on restart.
- Check Spring profile, datasource, RPC endpoints, thread pool settings, logging level, and feature flags resolve to the intended environment.
- Check secrets are not rendered into annotations, labels, command args, logs, or plain ConfigMaps.

## Networking

- Check container ports, Service ports, target ports, probe ports, and management ports line up.
- Check Ingress path, host, TLS, rewrite rules, timeouts, and body limits match Spring routing and actuator endpoints.
- Check NetworkPolicy or service mesh rules when the service calls DB, cache, MQ, or RPC dependencies.

## Security Context

- Check containers avoid privileged mode, host networking, host PID/IPC, broad capabilities, and writable root filesystem unless justified.
- Prefer non-root execution when the image supports it.
- Check service account scope, RBAC, projected tokens, and automount settings.
- Check image pull secrets and registry references are environment-appropriate.

## Workloads Beyond Deployment

- For `Job` and `CronJob`, check restart policy, backoff limit, concurrency policy, deadline, idempotency, and duplicate execution risk.
- For consumers and schedulers, check parallelism and rollout behavior do not process the same work twice without idempotency.
- For StatefulSet, check volume claim templates, ordered rollout, identity assumptions, and data migration safety.

## Reporting Findings

For each Kubernetes finding, include:

- Whether the issue is in the template input, rendered YAML, or both.
- The environment affected, if known.
- Production impact: failed rollout, traffic blackhole, restart loop, OOMKilled, throttling, secret leak, config drift, duplicate job execution, or failed autoscaling.
- The exact manifest path and field, such as `Deployment.spec.template.spec.containers[0].readinessProbe`.
- A practical fix and the validation command to run.

Severity guide:

- `P0`: secret exposure, destructive workload change, or guaranteed outage in production.
- `P1`: selector mismatch, invalid rendered manifest, missing critical readiness for routed service, OOM/restart-loop risk, broken rollout, or unsafe secret handling.
- `P2`: weak resources/probes/HPA/PDB, environment drift, brittle template defaults, or incomplete validation.
- `P3`: naming, labels, annotations, small redundancy, or maintainability of templates.

## Useful Validation Commands

Use project-provided commands first. Otherwise consider:

```bash
python3 /path/to/java-code-review/scripts/validate_helm_render.py <chart> --release <release> -f values.yaml --output rendered.yaml
helm lint <chart>
helm template <release> <chart> -f values.yaml
kustomize build <overlay>
kubectl kustomize <overlay>
kubectl apply --dry-run=server -f rendered.yaml
kubeconform -strict rendered.yaml
```

Only run cluster-dependent commands such as `kubectl apply --dry-run=server` when a target cluster context is intentionally available.

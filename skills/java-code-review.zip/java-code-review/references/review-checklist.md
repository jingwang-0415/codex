# Java Review Checklist

## Correctness

- Check nullability, empty collections, boundary values, integer overflow, decimal precision, time zone/date handling, enum default behavior, and exception paths.
- Check `equals`/`hashCode`, comparator consistency, mutable keys in maps, and collection mutation during iteration.
- Check whether changed behavior remains compatible with callers, API contracts, serialization, and persistence formats.
- Check whether errors are swallowed, wrapped without context, logged repeatedly, or converted into misleading success responses.

## Redundant Code

Identify redundancy explicitly:

- `dead code`: unused methods, fields, constants, branches, feature flags, private helpers, and unreachable code.
- Duplicate logic: repeated validation, mapping, defaulting, conversion, authorization, exception handling, or response construction.
- Duplicate data access: repeated DAO/mapper calls for the same key, loop-level queries that could be bulk queries, repeated count/list queries when one result can serve both.
- Pointless layers: pass-through methods, wrappers, adapters, or abstractions that add no policy, validation, isolation, or domain language.
- Useless state: cached values that are recomputed or never read, redundant local variables, unnecessary member fields, unnecessary `Atomic*` in single-threaded scope.
- Unused parameters and return values, especially in public methods where deletion may require compatibility review.
- Test redundancy: tests that assert the same happy path, mocks whose stubs are never used, setup data unrelated to assertions, and assertions that only verify implementation calls.

When reporting redundancy, include:

- Why it is redundant.
- Whether removal is safe now or needs caller/API compatibility checks.
- The simpler replacement or deletion target.

## Maintainability

- Prefer clear domain names over generic `handle`, `process`, `data`, `flag`, `type`.
- Check method size only when it hides multiple responsibilities or makes failure paths hard to reason about.
- Check whether conditionals encode business rules that deserve named methods, enums, or policy objects.
- Avoid premature abstraction. If only two small call sites exist, duplication may be cheaper than a vague abstraction.

## Security

- Check input validation, authorization, SQL injection, path traversal, SSRF, unsafe deserialization, command injection, weak crypto, secret exposure in logs, and unsafe file handling.
- Check data masking for logs, exceptions, audit records, and returned DTOs.
- Check trust boundaries: controller input, message input, RPC response, database content, and config values.

## UT Effectiveness

- Verify tests assert behavior, not just method calls or no exception.
- Look for missing negative paths, null/empty/boundary cases, permission failures, duplicate requests, DB empty result, and downstream failure.
- Watch for over-mocking. If all collaborators are mocked, the test may only prove the implementation mirrors the mock setup.
- When duplicate DB/RPC calls are a risk, check whether tests verify interaction count or observable query behavior; a loose mock stub can hide redundant execution.
- For database logic, decide whether unit, slice, or integration tests are needed. Mocking a mapper is usually not enough to validate SQL behavior.
- Prefer deterministic tests: no real time, random data, shared static state, order dependency, or unbounded async waits.

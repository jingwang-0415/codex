# Business and Architecture Review

Use this reference for MR/PR-based review, architecture review, compatibility review, and repository business knowledge creation.

## Repository Business Knowledge

Before a serious MR review, locate a business knowledge document. Search for:

- `CODEBASE_KNOWLEDGE.md`
- `ARCHITECTURE.md`
- `DOMAIN.md`
- `README.md`
- `docs/**/*.md`
- `design/**/*.md`
- `adr/**/*.md`
- `**/*.puml`
- `**/*.plantuml`
- requirement or product docs in the repo
- module-level README files

If the repo has no adequate document, create or update `CODEBASE_KNOWLEDGE.md` or `docs/codebase-knowledge.md` unless the user or repo convention points elsewhere. The document must help a reviewer understand the repository, not merely list files.

Minimum content:

- Repository purpose and business domains.
- Module structure and ownership boundaries.
- Main runtime flows: HTTP/RPC entry, service orchestration, repository/mapper, cache, MQ, scheduled jobs, and external dependencies.
- Core domain objects, DTOs, events, and persistence tables where inferable.
- Important architecture rules: layering, transaction placement, idempotency, error handling, logging, tenancy, permission model, and internal framework conventions.
- Deployment/runtime notes relevant to code behavior: profiles, config keys, thread pools, DB/cache/MQ dependencies, Helm chart location.
- Test strategy: unit, integration, DB, contract, and deployment validation.
- Open questions where business meaning or internal framework behavior cannot be inferred.
- Relevant PlantUML/PUML diagrams and whether they match implementation.

Do not invent business facts. Use evidence from docs, PlantUML/PUML diagrams, code names, package structure, controllers, service methods, database mappers, events, tests, and deployment config. Mark uncertain items as "待确认".

## Design Document and Implementation Consistency

Treat MD and PlantUML/PUML files as design intent, not absolute truth. They may be stale. When a changed code path is covered by a design document or diagram, compare the design to implementation.

Check these consistency points:

- Module/component relationship in diagrams vs actual package/module dependency.
- Sequence diagram call order vs actual caller/callee chain.
- Activity/state diagram branch conditions vs actual business branching.
- Class/entity diagram fields and relationships vs DTO/entity/table/mapper definitions.
- Deployment/component diagram dependencies vs Helm values, configs, RPC clients, MQ topics, DB/cache usage.
- Error/compensation/idempotency flow in docs vs actual exception, transaction, retry, and message behavior.

If inconsistent, report it directly in the review result when it affects changed code:

```text
文档/实现一致性
- [P2] 设计图与本次实现的调用链不一致
  文档: design/order-flow.puml:42
  代码: src/main/java/.../OrderService.java:88
  差异: PUML 表示先校验库存再创建订单，但代码先落订单再调用库存校验
  影响: 读者会按错误流程理解事务和补偿边界，后续改动可能继续扩大不一致
  建议: 若代码是正确设计，更新 PUML；若 PUML 是目标设计，调整实现和测试
```

Severity guidance:

- `P1`: inconsistency indicates a likely production bug, broken compatibility contract, wrong dependency, missing compensation, or incorrect deployment dependency.
- `P2`: inconsistency can mislead future changes, architecture decisions, tests, or operational runbooks.
- `P3`: naming/detail drift with low behavioral risk.

Do not force code to match stale docs blindly. Decide whether the likely fix is to update docs, update code, or mark a business decision as "需要确认".

## MR Review Workflow

1. Identify base and head. Prefer the MR/PR diff over whole-repo review.
2. List changed files by category: production Java, tests, SQL/migration, config, Helm/YAML, docs.
3. For each changed production file, identify changed symbols: class, method, field, API path, DTO field, mapper method, event type, config key, or template path.
4. Search design docs and PUML diagrams for changed domain terms, class names, method names, API paths, event names, table names, config keys, and module names.
5. Trace local context:
   - Caller: who invokes the changed method/API/event/template.
   - Callee: what DB/RPC/cache/MQ/file/threading/deployment behavior the changed code invokes.
   - Contract: what inputs, outputs, side effects, errors, transaction semantics, and compatibility expectations exist.
6. Compare relevant docs/diagrams with implementation for the changed flow.
7. Review tests against changed behavior, not just changed lines.
8. Report only findings tied to changed code or clearly affected context. Avoid broad unrelated cleanup.

Useful commands when working locally:

```bash
git diff --name-only <base>...<head>
git diff --stat <base>...<head>
git diff <base>...<head> -- path/to/file
rg -n "methodName|ClassName|apiPath|eventName|configKey" .
rg -n "methodName|ClassName|apiPath|eventName|configKey" --glob '*.md' --glob '*.puml' --glob '*.plantuml' .
```

## Architecture Rationality

Check whether the change preserves the intended architecture:

- Controller should handle protocol adaptation and validation, not core business rules.
- Service should own business orchestration and transaction boundary.
- Repository/Mapper should own data access, not remote calls or business branching.
- DTO/entity/domain object conversion should be explicit enough to avoid leaking persistence concerns across layers.
- Internal framework hooks, interceptors, annotations, and base classes should be respected.
- Cross-module dependencies should point in the intended direction. Watch for circular dependencies and domain leakage.
- Shared utilities should not become hidden business services.
- New abstractions should remove real duplication or isolate policy. Avoid vague manager/helper/facade layers that only forward calls.

Architecture findings should explain the expected boundary and the concrete harm from crossing it: compatibility break, transaction confusion, duplicated business rules, test brittleness, deployment coupling, or future change risk.

## Compatibility Checks

Treat these as compatibility-sensitive:

- Public Java method signatures used by other modules.
- Controller paths, request/response DTOs, validation annotations, error codes, and HTTP status behavior.
- RPC interfaces, events, MQ payloads, serialization names, enum values, and schema versions.
- Database schema, mapper SQL, index assumptions, default values, and migration order.
- Cache keys, TTLs, config keys, feature flags, Spring profiles, and Helm values.
- Thread pool names, queue settings, scheduler names, and deployment env vars.

For each compatibility-sensitive change, ask:

- Can old callers still compile and run?
- Can old data still be read?
- Can old messages/events still be consumed?
- Can old and new versions run simultaneously during rolling deployment?
- Are defaults safe when config or Helm values are absent?
- Do tests cover backward compatibility or mixed-version behavior where needed?

## Method Context Review

For a changed method, inspect:

- Input sources and validation before the method.
- Nullability, default values, and boundary conditions.
- Transaction context and whether the method is called across async/thread boundaries.
- Side effects: DB writes, cache mutation, MQ send, RPC call, file IO, audit log, metrics, and config changes.
- Error propagation and retry behavior.
- All direct callers in the repo, or representative callers if there are many.
- Direct callees that carry production risk: mapper, repository, RPC, cache, lock, executor, scheduler, or deployment config.

Do not claim a method is safe only because its body looks safe. Safety depends on how it is called.

## Business Knowledge Generation Quality Bar

A generated business knowledge MD is acceptable only if it enables a future reviewer to answer:

- What business capability does this repo provide?
- Which modules own which responsibilities?
- What are the main request/event/job flows?
- Which components are risky to change?
- What compatibility contracts exist?
- Which design docs/PUML diagrams are authoritative and which are stale?
- Which tests should be run for a change in a given module?

If the document cannot answer these, keep gathering context before relying on it.

#!/usr/bin/env python3
"""Render a Helm chart and validate the rendered YAML.

This script is intentionally dependency-light. It runs Helm, writes the rendered
manifest, and then tries several local YAML parsers if available.
"""

from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path


def run(cmd: list[str], *, capture: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, text=True, capture_output=capture, check=False)


def print_block(title: str, text: str) -> None:
    if text.strip():
        print(f"\n== {title} ==")
        print(text.rstrip())


def command_exists(name: str) -> bool:
    return shutil.which(name) is not None


def build_helm_args(args: argparse.Namespace) -> list[str]:
    helm_args: list[str] = []
    for values_file in args.values:
        helm_args.extend(["-f", values_file])
    for item in args.set_values:
        helm_args.extend(["--set", item])
    for item in args.set_string_values:
        helm_args.extend(["--set-string", item])
    for item in args.set_file_values:
        helm_args.extend(["--set-file", item])
    if args.namespace:
        helm_args.extend(["--namespace", args.namespace])
    return helm_args


def validate_with_python_yaml(path: Path) -> tuple[bool, str]:
    try:
        import yaml  # type: ignore
    except Exception as exc:  # pragma: no cover - depends on local environment
        return False, f"PyYAML unavailable: {exc}"

    try:
        with path.open("r", encoding="utf-8") as handle:
            list(yaml.safe_load_all(handle))
        return True, "YAML parsed successfully with PyYAML."
    except Exception as exc:
        return False, f"YAML parse failed with PyYAML: {exc}"


def validate_with_ruby(path: Path) -> tuple[bool, str]:
    if not command_exists("ruby"):
        return False, "ruby unavailable"
    proc = run(["ruby", "-e", "require 'yaml'; YAML.load_stream(File.read(ARGV[0]))", str(path)])
    if proc.returncode == 0:
        return True, "YAML parsed successfully with Ruby YAML."
    return False, (proc.stderr or proc.stdout or "Ruby YAML parse failed.").strip()


def validate_with_yq(path: Path) -> tuple[bool, str]:
    if not command_exists("yq"):
        return False, "yq unavailable"
    proc = run(["yq", "eval", ".", str(path)])
    if proc.returncode == 0:
        return True, "YAML parsed successfully with yq."
    return False, (proc.stderr or proc.stdout or "yq parse failed.").strip()


def validate_with_kubectl(path: Path) -> tuple[bool, str]:
    if not command_exists("kubectl"):
        return False, "kubectl unavailable"
    proc = run(["kubectl", "apply", "--dry-run=client", "--validate=false", "-f", str(path)])
    if proc.returncode == 0:
        return True, "YAML parsed successfully with kubectl client dry-run."
    return False, (proc.stderr or proc.stdout or "kubectl dry-run parse failed.").strip()


def validate_rendered_yaml(path: Path) -> bool:
    validators = [
        validate_with_python_yaml,
        validate_with_ruby,
        validate_with_yq,
        validate_with_kubectl,
    ]
    messages: list[str] = []
    for validator in validators:
        ok, message = validator(path)
        messages.append(message)
        if ok:
            print(f"[OK] {message}")
            return True
    print("[ERROR] No YAML validator succeeded.")
    for message in messages:
        print(f"- {message}")
    return False


def scan_template_risks(chart: Path) -> list[str]:
    warnings: list[str] = []
    templates_dir = chart / "templates"
    if not templates_dir.exists():
        return warnings

    for path in sorted(templates_dir.rglob("*")):
        if not path.is_file() or path.suffix not in {".yaml", ".yml", ".tpl"}:
            continue
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except UnicodeDecodeError:
            continue
        for idx, line in enumerate(lines, start=1):
            if "\t" in line:
                warnings.append(f"{path}:{idx}: contains a tab; YAML indentation must use spaces.")
            if "toYaml" in line and "indent" not in line:
                warnings.append(f"{path}:{idx}: toYaml without indent/nindent can render invalid nesting.")
            if re.search(r":\s*{{-?\s*if\b", line):
                warnings.append(f"{path}:{idx}: conditional after a YAML key can leave an empty key or join tokens.")
            if "{{-" in line and "-}}" in line and line.strip().startswith("{{-"):
                warnings.append(f"{path}:{idx}: aggressive whitespace trimming; check rendered line joins.")
    return warnings


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate Helm-rendered Kubernetes YAML.")
    parser.add_argument("chart", help="Path to the Helm chart directory.")
    parser.add_argument("--release", default="render-check", help="Release name for helm template.")
    parser.add_argument("--namespace", help="Namespace passed to helm template/lint.")
    parser.add_argument("-f", "--values", action="append", default=[], help="Values file. Can be repeated.")
    parser.add_argument("--set", dest="set_values", action="append", default=[], help="Helm --set value. Can be repeated.")
    parser.add_argument(
        "--set-string",
        dest="set_string_values",
        action="append",
        default=[],
        help="Helm --set-string value. Can be repeated.",
    )
    parser.add_argument(
        "--set-file",
        dest="set_file_values",
        action="append",
        default=[],
        help="Helm --set-file value. Can be repeated.",
    )
    parser.add_argument("--output", default="rendered.yaml", help="Path to write rendered YAML.")
    parser.add_argument("--skip-lint", action="store_true", help="Skip helm lint.")
    parser.add_argument("--strict-lint", action="store_true", help="Pass --strict to helm lint.")
    args = parser.parse_args()

    chart = Path(args.chart).resolve()
    output = Path(args.output).resolve()

    if not command_exists("helm"):
        print("[ERROR] helm command not found.")
        return 2
    if not chart.exists():
        print(f"[ERROR] chart path does not exist: {chart}")
        return 2

    helm_args = build_helm_args(args)

    if not args.skip_lint:
        lint_cmd = ["helm", "lint", str(chart), *helm_args]
        if args.strict_lint:
            lint_cmd.append("--strict")
        print(f"[RUN] {' '.join(lint_cmd)}")
        lint = run(lint_cmd)
        print_block("helm lint stdout", lint.stdout)
        print_block("helm lint stderr", lint.stderr)
        if lint.returncode != 0:
            print("[ERROR] helm lint failed.")
            return lint.returncode

    template_cmd = ["helm", "template", args.release, str(chart), *helm_args, "--debug"]
    print(f"[RUN] {' '.join(template_cmd)}")
    rendered = run(template_cmd)
    print_block("helm template stderr", rendered.stderr)
    if rendered.returncode != 0:
        print_block("helm template stdout", rendered.stdout)
        print("[ERROR] helm template failed. Fix the referenced template/line before reviewing Kubernetes semantics.")
        return rendered.returncode

    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(rendered.stdout, encoding="utf-8")
    print(f"[OK] rendered YAML written to {output}")

    parse_ok = validate_rendered_yaml(output)

    warnings = scan_template_risks(chart)
    if warnings:
        print("\n== Template whitespace risk warnings ==")
        for warning in warnings:
            print(f"- {warning}")

    return 0 if parse_ok else 1


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""Collect repository context for business-aware Java MR review.

The script does not infer business meaning by itself. It gathers evidence that
Codex can use to create or refresh CODEBASE_KNOWLEDGE.md.
"""

from __future__ import annotations

import argparse
import os
import re
import subprocess
import sys
from pathlib import Path


DOC_NAMES = {
    "README.md",
    "ARCHITECTURE.md",
    "CODEBASE_KNOWLEDGE.md",
    "DOMAIN.md",
}

SPRING_PATTERNS = [
    ("Controller", re.compile(r"@(RestController|Controller)\b")),
    ("Service", re.compile(r"@Service\b")),
    ("Repository/Mapper", re.compile(r"@(Repository|Mapper)\b|extends\s+(JpaRepository|Repository)\b")),
    ("Configuration", re.compile(r"@Configuration\b")),
    ("Scheduled", re.compile(r"@Scheduled\b")),
    ("Async", re.compile(r"@Async\b|CompletableFuture|Executor(Service)?\b")),
    ("Transactional", re.compile(r"@Transactional\b")),
    ("Message", re.compile(r"@(KafkaListener|RabbitListener|JmsListener)\b")),
]


def run_git(args: list[str], cwd: Path) -> str:
    proc = subprocess.run(["git", *args], cwd=cwd, text=True, capture_output=True, check=False)
    if proc.returncode != 0:
        return ""
    return proc.stdout.strip()


def is_ignored_dir(path: Path) -> bool:
    ignored = {".git", "target", "build", ".gradle", ".idea", ".mvn", "node_modules", "dist", "out"}
    return any(part in ignored for part in path.parts)


def iter_files(root: Path):
    for path in root.rglob("*"):
        if path.is_file() and not is_ignored_dir(path.relative_to(root)):
            yield path


def find_docs(root: Path) -> list[Path]:
    docs: list[Path] = []
    for path in iter_files(root):
        rel = path.relative_to(root)
        suffix = path.suffix.lower()
        if (
            path.name in DOC_NAMES
            or suffix in {".puml", ".plantuml"}
            or (suffix == ".md" and rel.parts and rel.parts[0] in {"docs", "design", "adr"})
        ):
            docs.append(path)
    return sorted(docs)


def find_build_files(root: Path) -> list[Path]:
    names = {"pom.xml", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts", "gradle.properties"}
    return sorted(path for path in iter_files(root) if path.name in names)


def find_deployment_files(root: Path) -> list[Path]:
    deployment: list[Path] = []
    for path in iter_files(root):
        rel = str(path.relative_to(root))
        if path.name == "Chart.yaml" or "templates/" in rel or path.name.startswith("values") and path.suffix in {".yaml", ".yml"}:
            deployment.append(path)
    return sorted(deployment)


def scan_java_components(root: Path, limit: int) -> list[tuple[str, Path]]:
    found: list[tuple[str, Path]] = []
    for path in iter_files(root):
        if path.suffix != ".java":
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for label, pattern in SPRING_PATTERNS:
            if pattern.search(text):
                found.append((label, path))
                break
        if len(found) >= limit:
            break
    return found


def changed_files(root: Path, base: str | None, head: str | None) -> list[str]:
    if base and head:
        output = run_git(["diff", "--name-only", f"{base}...{head}"], root)
    elif base:
        output = run_git(["diff", "--name-only", base], root)
    else:
        output = run_git(["status", "--short"], root)
        return [line[3:] for line in output.splitlines() if len(line) > 3]
    return [line for line in output.splitlines() if line]


def print_paths(title: str, root: Path, paths: list[Path], limit: int) -> None:
    print(f"\n## {title}")
    if not paths:
        print("- Not found")
        return
    for path in paths[:limit]:
        print(f"- {path.relative_to(root)}")
    if len(paths) > limit:
        print(f"- ... {len(paths) - limit} more")


def main() -> int:
    parser = argparse.ArgumentParser(description="Collect codebase context for business-aware Java review.")
    parser.add_argument("repo", nargs="?", default=".", help="Repository root.")
    parser.add_argument("--base", help="Base branch/commit for MR diff.")
    parser.add_argument("--head", help="Head branch/commit for MR diff.")
    parser.add_argument("--limit", type=int, default=80, help="Max entries per section.")
    args = parser.parse_args()

    root = Path(args.repo).resolve()
    if not root.exists():
        print(f"[ERROR] repo path does not exist: {root}", file=sys.stderr)
        return 2

    print("# Repository Knowledge Context")
    print(f"\nRepo: `{root}`")

    git_root = run_git(["rev-parse", "--show-toplevel"], root)
    if git_root:
        print(f"Git root: `{git_root}`")

    changes = changed_files(root, args.base, args.head)
    print("\n## Changed Files")
    if changes:
        for item in changes[: args.limit]:
            print(f"- {item}")
        if len(changes) > args.limit:
            print(f"- ... {len(changes) - args.limit} more")
    else:
        print("- No git changes detected or git metadata unavailable")

    print_paths("Business/Architecture Docs", root, find_docs(root), args.limit)
    print_paths("Build Files", root, find_build_files(root), args.limit)
    print_paths("Helm/Kubernetes Files", root, find_deployment_files(root), args.limit)

    print("\n## Spring/Java Component Candidates")
    components = scan_java_components(root, args.limit)
    if not components:
        print("- Not found")
    else:
        for label, path in components:
            print(f"- {label}: {path.relative_to(root)}")

    print("\n## Suggested CODEBASE_KNOWLEDGE.md Outline")
    print("- Repository purpose and business domains")
    print("- Module map and ownership boundaries")
    print("- Main request/RPC/job/message flows")
    print("- Domain model, DTOs, events, tables, and external dependencies")
    print("- Architecture rules and compatibility contracts")
    print("- Relevant MD/PUML design docs and implementation consistency notes")
    print("- Test and deployment validation strategy")
    print("- Open questions / 待确认")

    return 0


if __name__ == "__main__":
    sys.exit(main())
